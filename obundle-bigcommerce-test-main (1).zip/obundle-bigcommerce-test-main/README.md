I added code starting on line 50 to 110 in assets/js/theme/category.js. This code uses the storefront api to add product to cart and remove product from cart. also checks to see if products are in cart. i added a banner on the category page showing logged in customer name. I also made the image show with the products 2nd image on hover for Special Item.

Live Test Link: https://obundle-test64.mybigcommerce.com/
<br>
Preview Code: ngqrhylyk6
